package com.seckill.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seckill.user.entity.User;

public interface UserMapper extends BaseMapper<User> {

}