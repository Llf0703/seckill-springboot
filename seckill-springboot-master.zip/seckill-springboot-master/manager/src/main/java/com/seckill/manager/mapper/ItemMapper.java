package com.seckill.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seckill.manager.entity.Item;

public interface ItemMapper extends BaseMapper<Item> {

}