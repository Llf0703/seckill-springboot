package com.seckill.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seckill.manager.entity.Manager;

public interface ManagerMapper extends BaseMapper<Manager> {

}