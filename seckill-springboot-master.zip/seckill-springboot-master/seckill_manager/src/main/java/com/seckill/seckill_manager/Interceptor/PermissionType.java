package com.seckill.seckill_manager.Interceptor;

public interface PermissionType {
    int FinancialItemPermission = 1;
    int SeckillItemPermission = 2;
    int SeckillRecordPermission = 3;
    int RechargeRecordPermission=4;
    int AdminInfoPermission=5;
    int RiskControlPermission=6;
    int GuestInfoPermission=7;
}
