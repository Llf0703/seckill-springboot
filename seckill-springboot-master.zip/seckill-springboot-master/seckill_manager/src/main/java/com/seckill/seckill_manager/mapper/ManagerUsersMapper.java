package com.seckill.seckill_manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seckill.seckill_manager.entity.ManagerUsers;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wky1742095859
 * @since 2022-03-19
 */
public interface ManagerUsersMapper extends BaseMapper<ManagerUsers> {

}
