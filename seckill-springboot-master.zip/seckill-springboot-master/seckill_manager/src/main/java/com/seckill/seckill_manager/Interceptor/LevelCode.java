package com.seckill.seckill_manager.Interceptor;

public interface LevelCode {
    int DENIED=0;
    int READ=1;
    int EDIT=2;
}
